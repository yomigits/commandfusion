Imports System.Windows.Forms

Public Class DemoPlugin
    Implements CommandFusion.CFPlugin

    Public Event AddCommand(ByVal sender As CommandFusion.CFPlugin, ByVal newCommand As CommandFusion.SystemCommand) Implements CommandFusion.CFPlugin.AddCommand

    Public Event AddFeedback(ByVal sender As CommandFusion.CFPlugin, ByVal newFB As CommandFusion.SystemFeedback) Implements CommandFusion.CFPlugin.AddFeedback

    Public Event AddMacro(ByVal sender As CommandFusion.CFPlugin, ByVal ExistingSystem As CommandFusion.SystemClass, ByVal newMacro As CommandFusion.SystemMacro) Implements CommandFusion.CFPlugin.AddMacro

    Public Event AddSystem(ByVal sender As CommandFusion.CFPlugin, ByVal newSystem As CommandFusion.SystemClass) Implements CommandFusion.CFPlugin.AddSystem

    Public Property Author() As String Implements CommandFusion.CFPlugin.Author
        Get
            Return "Your name here"
        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Sub Dispose1() Implements CommandFusion.CFPlugin.Dispose

    End Sub

    Public Property Form() As System.Windows.Forms.Form Implements CommandFusion.CFPlugin.Form
        Get
            Return Me
        End Get
        Set(ByVal value As System.Windows.Forms.Form)

        End Set
    End Property

    Public Sub Init(ByVal menu As System.Windows.Forms.MainMenu) Implements CommandFusion.CFPlugin.Init
        Dim pluginMenu As New MenuItem("Demo Plugin")
        Dim showhideMenu As New MenuItem("Toggle Window")
        AddHandler showhideMenu.Click, AddressOf DoToggleWindow
        pluginMenu.MenuItems.Add(showhideMenu)
        menu.MenuItems.Add(pluginMenu)
    End Sub

    Public Sub DoToggleWindow(ByVal sender As Object, ByVal e As System.EventArgs)
        RaiseEvent ToggleWindow(Me)
    End Sub

    Public Property Name1() As String Implements CommandFusion.CFPlugin.Name
        Get
            Return "Demo Plugin"
        End Get
        Set(ByVal value As String)

        End Set
    End Property

    Public Sub ProjectSelected(ByVal selected As Boolean) Implements CommandFusion.CFPlugin.ProjectSelected

    End Sub

    Public Event RequestSystemList(ByVal sender As CommandFusion.CFPlugin) Implements CommandFusion.CFPlugin.RequestSystemList

    Public Event ToggleWindow(ByVal sender As CommandFusion.CFPlugin) Implements CommandFusion.CFPlugin.ToggleWindow

    Public Sub UpdateSystemList(ByVal systemList As System.Collections.Generic.List(Of CommandFusion.SystemClass)) Implements CommandFusion.CFPlugin.UpdateSystemList

    End Sub

    Public Event WriteToLog(ByVal sender As CommandFusion.CFPlugin, ByVal msg As String) Implements CommandFusion.CFPlugin.WriteToLog

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("Demo Plugin!")
    End Sub
End Class